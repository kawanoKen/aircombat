#-*-coding:utf-8-*-
from .common import loadWeights,saveWeights,loadPolicyWeights,savePolicyWeights

__all__ = [
    "loadWeights",
    "saveWeights",
    "loadPolicyWeights",
    "savePolicyWeights",
]